aftellen = input("Press enter to start")
i = 30 
for i in range(30 , -1, -1):
    print(i)
    
