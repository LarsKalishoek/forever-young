count = 20
for number in range(20, 51):
    if number % 2 == 0:
        count+= 1
        print(number) 
