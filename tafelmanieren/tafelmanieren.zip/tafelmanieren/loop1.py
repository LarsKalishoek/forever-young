tafel = input("Welk getal wil je: ")
for i in range (1 , 11):
    print(i*6)